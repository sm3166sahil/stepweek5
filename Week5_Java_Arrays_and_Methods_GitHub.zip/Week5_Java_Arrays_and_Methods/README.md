# STEP SEM-3 Week 5 — Java Arrays and Methods (Category C)

This folder contains solutions to both uploaded PDFs:
- `PracticeProblems.java`: all 5 Category C practice problems.
- `AssignmentProblems.java`: all 5 Category C assignment problems.

## Requirements
- JDK 8 or newer
- No external libraries required

## Compile and run (PowerShell)
```powershell
javac PracticeProblems.java
java PracticeProblems

javac AssignmentProblems.java
java AssignmentProblems
```

Each file contains its own `main()` method and prints sample results for all five problems.
The advanced problems use example-compatible eligibility thresholds and ranking formulas:
- Candidate eligibility: CGPA >= 7.5, or CGPA >= 6.5 and coding score >= 60.
- Candidate composite score: CGPA * 10 + coding score * 0.5.
- Player draftability: 10+ matches regardless of injury, or 5+ matches and not injured.
- Players are ranked by batting average, descending.

These thresholds/formula choices are implementation choices because the problem statements explicitly allow deciding them.
